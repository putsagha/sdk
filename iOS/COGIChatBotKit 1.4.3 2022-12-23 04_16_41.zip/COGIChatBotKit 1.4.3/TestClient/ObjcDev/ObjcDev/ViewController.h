//
//  ViewController.h
//  ObjcDev
//
//  Created by tokasia on 02/05/2019.
//  Copyright © 2019 mww. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ViewController : UIViewController


@end

