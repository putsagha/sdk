//
//  ChatBotViewControllerWithHeader.m
//  ObjcDev
//
//  Created by tokasia on 2020/06/26.
//  Copyright © 2020 mww. All rights reserved.
//

#import "ChatBotViewControllerWithHeader.h"

@interface ChatBotViewControllerWithHeader () 
@property (weak, nonatomic) IBOutlet COGIChatBotView *chatBotView;

@end

@implementation ChatBotViewControllerWithHeader
@synthesize config;
- (void)viewDidLoad {
    [super viewDidLoad];
    
	[self.chatBotView initialize:self.config];

}

- (void) chatBotViewDidClose:(COGIChatBotView *) chatBotView {
	NSLog(@"chatBotViewDidClose");
	[self.navigationController popViewControllerAnimated:YES];
}


@end
