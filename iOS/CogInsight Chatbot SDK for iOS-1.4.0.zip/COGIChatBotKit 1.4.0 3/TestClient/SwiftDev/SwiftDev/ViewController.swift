//
//  ViewController.swift
//  SwiftDev
//
//  Created by tokasia on 02/05/2019.
//  Copyright © 2019 mww. All rights reserved.
//

import UIKit
import COGIChatBotKit

class ViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, UINavigationControllerDelegate {
	
	var webView: WKWebView?
	let interfaceName = "observe"
	
	@IBOutlet weak var tfDashboardServer: UITextField!
	@IBOutlet weak var tfChatbotServer: UITextField!
	
	var apiKeys = ""
	
	@IBAction func onSelect(_ sender: Any) {
		guard let dashboardServerAddr = tfDashboardServer.text else { return }
		
		UserDefaults.standard.set(dashboardServerAddr, forKey: "dashboardServerAddr")
		
		let webConfiguration = WKWebViewConfiguration()
		let contentController = WKUserContentController()
		contentController.add(self, name: self.interfaceName)
		webConfiguration.userContentController = contentController
		
		let webView = WKWebView(frame: view.frame, configuration: webConfiguration)
		view.addSubview(webView)
		webView.navigationDelegate = self
		webView.load(URLRequest(url: URL(string: "\(dashboardServerAddr)/#/sdk-test")!))
		self.webView = webView
	}
	
	func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
		guard let chatbotServerAddr = tfChatbotServer.text else { return }
		
		if message.name == self.interfaceName {
			guard let body = message.body as? NSDictionary else { return }
			guard let event = body["event"] as? String else { return }
			switch event {
			case "domain-change":
				self.apiKeys = ""
				guard let domain = body["domain"] as? NSDictionary else { return }
				print("domain : \(domain)")
				if let apiKeys = domain["apiKeys"] as? String {
					self.apiKeys = apiKeys
				}
				
				
			case "project-change":
				guard let project = body["project"] as? NSDictionary else { return }
				
				print("project : \(project) ")
				let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChatBotViewControllerWithHeader") as! ChatBotViewControllerWithHeader
				vc.modalPresentationStyle = .fullScreen
				if let projectId = project["id"] as? String {
					vc.projectId = projectId
				}
				vc.serviceUrl = chatbotServerAddr
				if self.apiKeys.count > 0 {
					vc.isAuthMode = true
					vc.apiKey = self.apiKeys
				}
				self.present(vc, animated: true)

			default:
				print("not supported event - \(event)")
			}
		}
	}
	
	
	
	override func viewDidLoad() {
		super.viewDidLoad()
//		tfDashboardServer.text = UserDefaults.standard.object(forKey: "dashboardServerAddr") as? String ?? "http://192.168.10.106:3313"
//		tfChatbotServer.text = UserDefaults.standard.object(forKey: "chatbotServerAddr") as? String ?? "http://192.168.10.106:3311"
	}
	

	@IBAction func onChatBotViewWithHeader(_ sender: Any) {
		let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChatBotViewControllerWithHeader") as! ChatBotViewControllerWithHeader
		vc.modalPresentationStyle = .fullScreen
		vc.useHeader = true
		self.present(vc, animated: true)
	}
	
	@IBAction func onChatBotViewWithAuth(_ sender: Any) {
		let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChatBotViewControllerWithAuth") as! ChatBotViewControllerWithAuth
		vc.modalPresentationStyle = .fullScreen
		vc.isAuthMode = true
		self.present(vc, animated: true)
	}
	
	
	@IBAction func onChatBotViewWithDefaultHeader(_ sender: Any) {
		let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChatBotViewControllerWithDefaultHeader") as! ChatBotViewControllerWithDefaultHeader
		vc.modalPresentationStyle = .fullScreen
		self.present(vc, animated: true)
	}
	
    @IBAction func onMessageKitTest(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MessageKitViewController") as! MessageKitViewController
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
}

