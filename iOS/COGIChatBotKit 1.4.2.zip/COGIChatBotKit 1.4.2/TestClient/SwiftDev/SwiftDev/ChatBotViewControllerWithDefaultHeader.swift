//
//  ChatBotViewControllerWithDefaultHeader.swift
//  SwiftDev
//
//  Created by tokasia on 2020/09/14.
//  Copyright © 2020 mww. All rights reserved.
//

import UIKit
import COGIChatBotKit

class ChatBotViewControllerWithDefaultHeader: UIViewController, COGIChatBotViewDelegate {

	@IBOutlet weak var chatView: COGIChatBotView!
	
		var projectId = "a885f8ac-310a-41e6-b394-b68fdc28cf2a" //"99b35134-5fdf-4f04-96b4-09bf3e560996"
		let serviceUrl = "https://v2.aiware.io/service"

	override func viewDidLoad() {
        super.viewDidLoad()

		self.startChatbot()
    }
    
	func startChatbot() {
		let config = COGIChatBotConfig()
		config.hostUrl = self.serviceUrl
		config.projectId = self.projectId
		config.delegate = self
		config.resizeOnKeyboard = true

		config.backBtnImg = UIImage(named: "backImg")!
//			config.resetBtnImg = UIImage(named: "resetImg")!
		config.headerHeight = 32+8+8
		config.statusbarHeight = 0
		config.headerBgColor = UIColor(red: 245.0/255, green: 245.0/255, blue: 245.0/255, alpha: 1.0)

		self.chatView.initialize(config)
		
		let resetBtn = UIButton(frame: CGRect.zero)
		resetBtn.setTitle("처음으로", for: .normal)
		resetBtn.setTitleColor(UIColor(red: 0.0/255, green: 112/255, blue: 240.0/255, alpha: 1.0), for: .normal)
		resetBtn.addTarget(self, action: #selector(onReset), for: .touchUpInside)
		resetBtn.contentHorizontalAlignment = .right
		resetBtn.titleLabel?.font = .systemFont(ofSize: 15)
		self.chatView.headerView.addSubview(resetBtn)

		resetBtn.translatesAutoresizingMaskIntoConstraints = false
		NSLayoutConstraint(item: resetBtn, attribute: .trailing, relatedBy: .equal, toItem: self.chatView.headerView, attribute: .trailing, multiplier: 1.0, constant: -16).isActive = true
		NSLayoutConstraint(item: resetBtn, attribute: .top, relatedBy: .equal, toItem: self.chatView.headerView, attribute: .top, multiplier: 1.0, constant: 6).isActive = true
		NSLayoutConstraint(item: resetBtn, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 73).isActive = true
		NSLayoutConstraint(item: resetBtn, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 48).isActive = true

	}

	@objc func onReset() {
//		print("reset")
        self.chatView.inputExtra(["reset": "true"])
	}

	// 챗봇 닫힐때 이벤트
	func chatBotViewDidClose(_ chatBotView: COGIChatBotView!) {
		print("close")
		self.dismiss(animated: true, completion: nil)
	}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
