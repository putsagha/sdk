//
//  ViewController.m
//  ObjcDev
//
//  Created by tokasia on 02/05/2019.
//  Copyright © 2019 mww. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <COGIChatBotKit/COGIChatBotKit.h>

#import "ChatBotViewController.h"
#import "ChatBotViewControllerWithHeader.h"
#import "ChatBotViewControllerWithCustomHeader.h"
#import "MessageKitViewController.h"

@interface ViewController () <COGIChatBotViewDelegate, CLLocationManagerDelegate>
@property (nonatomic, retain) COGIChatBotView *chatBotView;
@property (nonatomic, retain) COGIChatBotViewController *chatBotViewController;
@property (nonatomic, retain) CLLocationManager *locationManager;
@end

@implementation ViewController
@synthesize chatBotView, chatBotViewController;

static NSString *hostUrl = @"https://v2.aiware.io/service";
static NSString *projectId = @"8faa8b42-78d2-4227-b555-7e9231621d05";
static NSString *apiKey = @"Kh63qx14qq97UxKvQpgPvB3h9MN2b0tW604ebxh6oSToH9FmLOvLITDBw6ump9jQaooT0GqBEU6NtemEP3qd9Q==|jNKxJ4vrKTTOwrJibbJSlwMjTYb0KtuFxoLdDjPwDsM=";


- (void)viewDidLoad {
	[super viewDidLoad];
	
	self.locationManager = [[CLLocationManager alloc]init];
	[self.locationManager requestWhenInUseAuthorization];
	self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
	self.locationManager.delegate = self;
	

	if(floor(NSFoundationVersionNumber) < NSFoundationVersionNumber_iOS_8_0){
		UILabel * notice  = [[UILabel alloc] init];
		[notice  setTextAlignment:(NSTextAlignmentCenter)];
		[notice setText:@"채팅상담은 iOS 8.0 부터 지원됩니다."];
		[self.view addSubview:notice];
	}
}


// storyboard 방식
// no header
- (IBAction)onChatbotViewWithSB:(id)sender {
	UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
	ChatBotViewController* vc = [storyboard instantiateViewControllerWithIdentifier:@"ChatBotViewController"];
	vc.config = [[COGIChatBotConfig alloc] init];
	vc.config.hostUrl = hostUrl;
	vc.config.projectId = projectId;
	vc.config.delegate = vc;
	
	vc.config.resizeOnKeyboard = true;

	[self.navigationController pushViewController:vc animated:YES];

}

// header
- (IBAction)onheaderChatbotViewWithSB:(id)sender {
	UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
	ChatBotViewControllerWithHeader* vc = [storyboard instantiateViewControllerWithIdentifier:@"ChatBotViewControllerWithHeader"];
	vc.config = [[COGIChatBotConfig alloc] init];
	vc.config.hostUrl = hostUrl;
	vc.config.projectId = projectId;
	vc.config.delegate = vc;

	// with header
	vc.config.backBtnImg = [UIImage imageNamed:@"backImg"];
	vc.config.headerHeight = 32+8+8;
	vc.config.statusbarHeight = 0;
	vc.config.headerBgColor = [UIColor colorWithRed:245.0/255 green:245.0/255 blue:245.0/255 alpha:1.0];

	vc.config.resizeOnKeyboard = true;

	[self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)onCustomHeaderChatbotViewWithSB:(id)sender {
	UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
	ChatBotViewControllerWithCustomHeader* vc = [storyboard instantiateViewControllerWithIdentifier:@"ChatBotViewControllerWithCustomHeader"];
	vc.config = [[COGIChatBotConfig alloc] init];
	vc.config.hostUrl = hostUrl;
	vc.config.projectId = projectId;
	vc.config.delegate = vc;

	vc.config.resizeOnKeyboard = true;

	[self.navigationController pushViewController:vc animated:YES];
}

// View방식
- (IBAction)onChatBotView:(id)sender {
	COGIChatBotConfig *config = [[COGIChatBotConfig alloc] init];
	config.hostUrl = hostUrl;
	config.projectId = projectId;
	config.delegate = self;

	COGIChatBotView *chatBotView = [[COGIChatBotView alloc] initWithConfig:config];
	chatBotView.translatesAutoresizingMaskIntoConstraints = YES;
	chatBotView.frame = self.view.frame;

	[self.view addSubview:chatBotView];
	
}

- (IBAction)onHeaderChatBotView:(id)sender {
	COGIChatBotConfig *config = [[COGIChatBotConfig alloc] init];
	config.hostUrl = hostUrl;
	config.projectId = projectId;
	config.delegate = self;

	// with header
	config.backBtnImg = [UIImage imageNamed:@"backImg"];
	config.headerHeight = 32+8+8;
	config.headerBgColor = [UIColor colorWithRed:245.0/255 green:245.0/255 blue:245.0/255 alpha:1.0];
	
	self.chatBotView = [[COGIChatBotView alloc] initWithConfig:config];
	chatBotView.translatesAutoresizingMaskIntoConstraints = YES;
	self.chatBotView.frame = self.view.frame;
	[self.view addSubview:self.chatBotView];
}

- (IBAction)onHeaderChatBotViewWithAuth:(id)sender {
	COGIChatBotConfig *config = [[COGIChatBotConfig alloc] init];
	config.hostUrl = hostUrl;
	config.projectId = projectId;
	config.delegate = self;

	// with header
	config.backBtnImg = [UIImage imageNamed:@"backImg"];
	config.headerHeight = 32+8+8;
	config.headerBgColor = [UIColor colorWithRed:245.0/255 green:245.0/255 blue:245.0/255 alpha:1.0];

	// with auth
	config.apiKey = apiKey;
	config.userKey = [[NSUUID UUID] UUIDString];
	config.secure = @{ @"name": @"test00" };
	
	self.chatBotView = [[COGIChatBotView alloc] initWithConfig:config];
	chatBotView.translatesAutoresizingMaskIntoConstraints = YES;
	self.chatBotView.frame = self.view.frame;
	[self.view addSubview:self.chatBotView];
}


// ViewController방식
- (IBAction)onChatBotViewController:(id)sender {
	COGIChatBotConfig *config = [[COGIChatBotConfig alloc] init];
	config.allowSelfSignedCert = YES;
	config.hostUrl = hostUrl;
	config.projectId = projectId;
	config.delegate = self;
	
	// with header
//	config.title = @"챗봇상담";
//	config.headerBgColor = [UIColor blueColor];
//	config.headerTxtColor = [UIColor whiteColor];
//	config.backBtnImg = [UIImage imageNamed:@"backImg"];
//	config.headerHeight = 64;
//	config.navController = self.navigationController;
	
	self.chatBotViewController = [[COGIChatBotViewController alloc] initWithConfig:config];
	[self.navigationController pushViewController:self.chatBotViewController animated:YES];
}

- (IBAction)onChatBotViewControllerWithAuth:(id)sender {
	COGIChatBotConfig *config = [[COGIChatBotConfig alloc] init];
	config.allowSelfSignedCert = YES;
	config.hostUrl = hostUrl;
	config.projectId = projectId;
	config.delegate = self;
	
	// with header
	config.title = @"챗봇상담";
	config.headerBgColor = [UIColor blueColor];
	config.headerTxtColor = [UIColor whiteColor];
	config.backBtnImg = [UIImage imageNamed:@"backImg"];
	config.headerHeight = 64;
	config.navController = self.navigationController;

	// with auth
	config.apiKey = apiKey;
	config.userKey = [[NSUUID UUID] UUIDString];
	config.secure = @{ @"name": @"test00" };

	self.chatBotViewController = [[COGIChatBotViewController alloc] initWithConfig:config];
	[self.navigationController pushViewController:self.chatBotViewController animated:YES];
}

- (IBAction)onMessageKitStt:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    MessageKitViewController* vc = [storyboard instantiateViewControllerWithIdentifier:@"MessageKitViewController"];
    [self.navigationController pushViewController:vc animated:YES];

}

#pragma mark - ChatBotViewDelegate
// 로딩 시작 이벤트
- (void)chatBotViewDidStartLoad:(COGIChatBotView *)chatBotView{
	NSLog(@"started");
}

// 로딩 완료 이벤트
- (void)chatBotViewDidFinishLoad:(COGIChatBotView *)chatBotView{
	// chatbot 이 로드되면 location service를 시작한다.
	[self.locationManager startUpdatingLocation];
}

// 로딩실패 -  닫기 처리등을 하여 이전  화면으로 돌아간다.
- (void)chatBotViewDidFailLoad:(COGIChatBotView *)chatBotView{
	[self dismissViewControllerAnimated:TRUE completion:nil];
}

//오류 메시지
- (void)chatBotView:(COGIChatBotView *)chatBotView didReceiveError:(NSString *)message{
	NSLog(@"error : %@", message);
}

//action 이벤트 처리 / Postfront button, cg-action postfront 처리
- (void)chatBotView:(COGIChatBotView *)chatBotView action:(NSString *)data{
	NSLog(@"action >>> %@", data);
	if ([data isKindOfClass:[NSDictionary class]]) {
		NSString * name = [((NSDictionary *)data) valueForKey:@"name"];
		NSLog(@"name : %@", name);
	} else if ([data isKindOfClass:[NSString class]]) {
		id json = [NSJSONSerialization JSONObjectWithData:[(NSString*)data dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
		NSLog(@"%@", json);
	}
}

// 헤더 챗봇 back버튼 클릭시 처리
- (void)chatBotViewDidClose:(COGIChatBotView *)chatBotView {
	if (self.chatBotView) {
		[self.chatBotView removeFromSuperview];
		self.chatBotView = nil;
	}
	if (self.chatBotViewController) {
		[self.navigationController popViewControllerAnimated:NO];
		self.chatBotViewController = nil;
	}
}

// 유저 메세지가 전송됬을때 호출
- (void)chatBotViewChatMessageSent:(COGIChatBotView *)chatBotView {
	NSLog(@"sent!!!");
}



#pragma mark CLLocationManagerDelegate
// location정보를  챗봇에 업데이트 한다
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
	CLLocation *location = [locations lastObject];
	NSDictionary *loc = @{
						  @"latitude" : @"111",//[NSNumber numberWithDouble:location.coordinate.latitude ],
						  @"longitude" : @"222"//[NSNumber numberWithDouble:location.coordinate.longitude ]
						  };
	if (chatBotView) {
		[chatBotView sendMessage:@"LOCATION_UPDATE" data:loc];
	}
	
	if (chatBotViewController) {
		[chatBotViewController.chatBotView sendMessage:@"LOCATION_UPDATE" data:loc];
	}
}



@end
