//
//  MessageKitViewController.h
//  ObjcDev
//
//  Created by toka on 2022/07/20.
//  Copyright © 2022 mww. All rights reserved.
//

#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN

@class COGIMessageKit;

@interface MessageKitViewController : ViewController

@property (nonatomic, strong) COGIMessageKit *messageKit;

@end

NS_ASSUME_NONNULL_END
