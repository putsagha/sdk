//
//  ChatBotViewController.m
//  ObjcDev
//
//  Created by tokasia on 2020/03/02.
//  Copyright © 2020 mww. All rights reserved.
//

#import "ChatBotViewController.h"


@interface ChatBotViewController () <COGIChatBotViewDelegate>
@property (weak, nonatomic) IBOutlet COGIChatBotView *chatBotView;

@end

@implementation ChatBotViewController
@synthesize config;

- (void)viewDidLoad {
    [super viewDidLoad];


	[self.chatBotView initialize:self.config];
}
// 유저 메세지가 전송됬을때 호출
- (void)chatBotViewChatMessageSent:(COGIChatBotView *)chatBotView {
	NSLog(@"sent!!!");
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
