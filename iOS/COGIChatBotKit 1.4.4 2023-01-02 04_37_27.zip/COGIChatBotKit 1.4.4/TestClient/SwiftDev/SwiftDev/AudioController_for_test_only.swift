//
//  AudioController.swift
//  SwiftDev
//
//  Created by toka on 2022/07/11.
//  Copyright © 2022 mww. All rights reserved.
//




import Foundation
import AVFAudio

protocol AudioControllerDelegate : NSObject {
    func processSampleData(data: Data) -> Void
}

// For Test only
class AudioController_for_test_only : NSObject {
    
    static let sharedInstance = AudioController_for_test_only()
    weak var delegate:AudioControllerDelegate? = nil
    private var remoteIOUnit: AudioComponentInstance? = nil
    
    private override init() {
        super.init()
    }
    
    deinit {
        AudioComponentInstanceDispose(remoteIOUnit!)
    }
    
    func prepare(sampleRate: Double, channels: UInt32) {
        let session = AVAudioSession.sharedInstance()
//        try? session.setCategory(.record, mode: .measurement, options: .duckOthers)
//        try? session.setActive(true, options: .notifyOthersOnDeactivation)
        try? session.setCategory(.playAndRecord)
        
        var audioComponentDescription = AudioComponentDescription(componentType: kAudioUnitType_Output, componentSubType: kAudioUnitSubType_RemoteIO, componentManufacturer: kAudioUnitManufacturer_Apple, componentFlags: 0, componentFlagsMask: 0)
        
        let remoteIOComponent = AudioComponentFindNext(nil, &audioComponentDescription)
        AudioComponentInstanceNew(remoteIOComponent!, &(self.remoteIOUnit))
        
        var oneFlag:UInt32 = 1
        let bus1: AudioUnitElement = 1
        
        AudioUnitSetProperty(self.remoteIOUnit!, kAudioOutputUnitProperty_EnableIO, kAudioUnitScope_Input, bus1, &oneFlag, UInt32(MemoryLayout<UInt32>.size))
        
        var asbd = AudioStreamBasicDescription(mSampleRate: sampleRate, mFormatID: kAudioFormatLinearPCM, mFormatFlags: (kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked), mBytesPerPacket: 2, mFramesPerPacket: 1, mBytesPerFrame: 2, mChannelsPerFrame: channels, mBitsPerChannel: 16, mReserved: 0)
        AudioUnitSetProperty(self.remoteIOUnit!, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Output, bus1, &asbd, UInt32(MemoryLayout<AudioStreamBasicDescription>.size))
        
        var callbackStruct = AURenderCallbackStruct(inputProc: AudioController_for_test_only.recordingCallback, inputProcRefCon: UnsafeMutableRawPointer( Unmanaged.passUnretained(self).toOpaque()))
        AudioUnitSetProperty(self.remoteIOUnit!, kAudioOutputUnitProperty_SetInputCallback, kAudioUnitScope_Global, bus1, &callbackStruct, UInt32(MemoryLayout.size(ofValue: callbackStruct)))
        
        AudioUnitInitialize(self.remoteIOUnit!)
    }
    
    func start() -> OSStatus {
        return AudioOutputUnitStart(self.remoteIOUnit!)
    }
    
    func stop() -> OSStatus {
        return AudioOutputUnitStop(self.remoteIOUnit!)
    }
    
    static let recordingCallback:AURenderCallback = { (
        inRefCon,
        ioActionFlags,
        inTimeStamp,
        inBufNumber,
        inNumberFrames,
        ioData) -> OSStatus in
        
        let audiocontroller = unsafeBitCast(inRefCon, to: AudioController_for_test_only.self)
        let channelCount : Int = 1
        var bufferList = AudioBufferList.allocate(maximumBuffers: channelCount)
        bufferList[0] = AudioBuffer(mNumberChannels: 1, mDataByteSize: UInt32(inNumberFrames * 2), mData: nil)
        let status = AudioUnitRender(audiocontroller.remoteIOUnit!, ioActionFlags, inTimeStamp, inBufNumber, inNumberFrames, bufferList.unsafeMutablePointer)

        if status != noErr {
            return status
        }

        let data = Data(bytes: bufferList[0].mData!, count: Int(bufferList[0].mDataByteSize))
        DispatchQueue.main.async {
            audiocontroller.delegate?.processSampleData(data: data)
        }
        
        return noErr
    }
    
}
