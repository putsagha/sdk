//
//  ChatBotViewControllerWithAuth.swift
//  SwiftDev
//
//  Created by tokasia on 2020/06/29.
//  Copyright © 2020 mww. All rights reserved.
//

import UIKit
import COGIChatBotKit
import CoreLocation

class ChatBotViewControllerWithAuth: UIViewController, COGIChatBotViewDelegate, CLLocationManagerDelegate {
//	var chatBotView: COGIChatBotView?
  
	@IBOutlet weak var chatView: COGIChatBotView!
	
    
	var locationManager: CLLocationManager?

    var hostUrl = "https://v2.aiware.io/service"
    var projectId = "e3789209-7ea0-481e-98d2-25562889e2dd"
    var apiKey =  "gG5i9K0iXvVRtEvnC91QZi7eO57KbIPOXHlc4CcxCMwD4jaWwRrUcZinPNleDnT1xP20PxVy3fkXsYc9YVOxjw==|BQYIxqjTb9rFNmwFgqdP44GnsVbrzTGLaPgEewO8aBY="

	var isAuthMode = true  // 인증 사용시 true로 세팅
	var useHeader = false
	
	@IBOutlet weak var customHeaderHeight: NSLayoutConstraint!
	override func viewDidLoad() {
        super.viewDidLoad()
		self.locationManager = CLLocationManager()
		self.locationManager?.requestWhenInUseAuthorization()
		self.locationManager?.desiredAccuracy = kCLLocationAccuracyBest
		self.locationManager?.delegate = self

		self.startChatbot()
    }
    
	func startChatbot() {
		let config = COGIChatBotConfig()
		config.hostUrl = self.hostUrl
		config.projectId = self.projectId
		config.delegate = self
		if isAuthMode {
			config.apiKey = apiKey
			config.userKey = "test2"
			config.secure = [
				"name" : "ddd"
			]
		}
		config.encrypt = false   // secure data encrypt 지원시 true 미지원시 false
//		config.input = "{\"reset\":\"true\", \"text\":\"ph\"}"
//		config.extra = "feature=native_audio_recording"
		config.resizeOnKeyboard = true

		self.chatView.initialize(config)

	}

	@IBAction func onBack(_ sender: Any) {
		self.presentingViewController?.dismiss(animated: true, completion: nil)
	}
	
	// MARK: - CLLocationManagerDelegate
	// location정보를  챗봇에 업데이트 한다
	func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
		let location = locations.last as? CLLocation
		let loc = [
			"latitude": location?.coordinate.latitude ?? 0.0,
			"longitude": location?.coordinate.longitude ?? 0.0
		]
		let encoder = JSONEncoder()
		if let jsonData = try? encoder.encode(loc) {
			if let jsonString = String(data: jsonData, encoding: .utf8) {
				print(jsonString)
				self.chatView.sendMessage("LOCATION_UPDATE", data: jsonString as NSObject)
			}
		}
	}
	// MARK: - COGIChatBotViewDelegate
	// 로딩 시작 이벤트
	func chatBotViewDidStartLoad(_ chatBotView: COGIChatBotView?) {
	}
	
	// 로딩 완료 이벤트
	func chatBotViewDidFinishLoad(_ chatBotView: COGIChatBotView!) {
		self.locationManager?.startUpdatingLocation()
//			self.chatBotView?.sendMessage("MSG_INPUT", data: #"{"result":"success"}"# as NSObject)
	}

	// 챗봇 닫힐때 이벤트
	func chatBotViewDidClose(_ chatBotView: COGIChatBotView!) {
		print("close")
		self.dismiss(animated: true, completion: nil)
	}

	// 로딩실패 -  닫기 처리등을 하여 이전  화면으로 돌아간다.
	func chatBotViewDidFailLoad(_ chatBotView: COGIChatBotView?) {
	}

	// 유저 메세지가 전송됬을때 호출
	func chatBotViewChatMessageSent(_ chatBotView: COGIChatBotView!) {
		print("sent")
	}
	
	//오류 메시지
	func chatBotView(_ chatBotView: COGIChatBotView!, didReceiveError message: String!) {
		print(message)
	}
	
	
	//action 이벤트 처리 / Postfront button 처리
	func chatBotView(_ chatBotView: COGIChatBotView?, action data: String?) {
		print("action >>> \(data)")
		if let data = data?.data(using: .utf8) {
			do {
				if let json = try JSONSerialization.jsonObject(with: data, options : []) as? [String: AnyObject]
				{
					if let type = json["type"] as? String {
						switch type {
						case "new":
							print("new")
						default:
							print("type : \(type)")
						}
					}
				} else {
					print("bad json")
				}
			} catch let error as NSError {
				print(error)
			}

		}
	}
}
