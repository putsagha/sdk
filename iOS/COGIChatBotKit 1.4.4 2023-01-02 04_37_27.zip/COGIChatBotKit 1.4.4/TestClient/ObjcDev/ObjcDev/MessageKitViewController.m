//
//  MessageKitViewController.m
//  ObjcDev
//
//  Created by toka on 2022/07/20.
//  Copyright © 2022 mww. All rights reserved.
//

#import "MessageKitViewController.h"
#import "COGIChatBotKit/COGIChatBotKit.h"
#import "AVFAudio/AVFAudio.h"


static NSString * hostUrl = @"https://v2.aiware.io/service";
static NSString * projectId = @"e3789209-7ea0-481e-98d2-25562889e2dd";
static NSString * apiKey = @"gG5i9K0iXvVRtEvnC91QZi7eO57KbIPOXHlc4CcxCMwD4jaWwRrUcZinPNleDnT1xP20PxVy3fkXsYc9YVOxjw==|BQYIxqjTb9rFNmwFgqdP44GnsVbrzTGLaPgEewO8aBY=";


@interface MessageKitViewController () <COGIMessageKitDelegate>
@property (weak, nonatomic) IBOutlet UITextField *tfInput;
@property (weak, nonatomic) IBOutlet UILabel *lblStatus;
@property (weak, nonatomic) IBOutlet UILabel *lblSttText;
@property (weak, nonatomic) IBOutlet UILabel *lblOutputText;
@property (weak, nonatomic) IBOutlet UITextView *tvOutputMessage;

@property (weak, nonatomic) IBOutlet UIButton *btnSendInput;
@property (weak, nonatomic) IBOutlet UIButton *btnRecordStart;
@property (weak, nonatomic) IBOutlet UIButton *btnSendStt;
@property (weak, nonatomic) IBOutlet UIButton *btnSendTts;

@property (strong, nonatomic) COGIMessageOutput* messageOutput;
@property (strong, nonatomic) COGISttResult* sttResult;

@property (strong, nonatomic) AVAudioPlayer* audioPlayer;
@end

@implementation MessageKitViewController
@synthesize messageKit, tfInput, lblStatus, lblSttText, lblOutputText, tvOutputMessage, messageOutput, btnSendInput, btnRecordStart, btnSendStt, btnSendTts, sttResult;

- (void)viewDidLoad {
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(onTabBG:)];
    [self.view addGestureRecognizer:tapGesture];
    
    [self startMessageKit];
}
 
- (void)onTabBG:(UIGestureRecognizer *)gesture{
    [self.view endEditing:TRUE];
}
- (IBAction)onClose:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)onSendText:(id)sender {
    [self.messageKit inputMessage:self.tfInput.text];
    [self.view endEditing:TRUE];
    
}
- (IBAction)onRecordStart:(id)sender {
    [self.messageKit startStt];
}
- (IBAction)onRecordStop:(id)sender {
    [self.messageKit stopStt];
}
- (IBAction)onSendSttResult:(id)sender {
    if (self.sttResult) {
        [self.messageKit inputSttMessage:self.sttResult];
    }
}
- (IBAction)onRequestTts:(id)sender {
    if (self.messageOutput) {
        [self.messageKit requestTtsData:self.messageOutput];
    }
}

///////////////////////////
- (void)startMessageKit {
    COGIMessageKitConfig* config = [[COGIMessageKitConfig alloc] init];
    config.hostUrl = hostUrl;
    config.projectId = projectId;
    config.apiKey = apiKey;
    config.userKey = @"userKey1";
    config.encrypt = YES;
    config.allowSelfSignedCert = YES;
    config.delegate = self;
    
    [self enableControl:NO];
    self.messageKit = [[COGIMessageKit alloc] initWithConfig:config];
}
- (void)enableControl:(BOOL)enable {
    [btnSendInput setEnabled:enable];
    [btnRecordStart setEnabled:enable];
    [btnSendStt setEnabled:enable];
    [btnSendTts setEnabled:enable];
}

#pragma mark - COGIMessageKitDelegate
- (void)messageKitDidStartLoad:(COGIMessageKit *)messageKit {
    NSLog(@"start load");
}

- (void)messageKitDidFinishLoad:(COGIMessageKit *)messageKit {
    NSLog(@"finish load");
    [self enableControl:YES];
}

- (void)messageKitMessageSent:(COGIMessageKit *)messageKit {
    NSLog(@"message sent");
}

- (void)messageKitMessageReceived:(COGIMessageKit *)messageKit data:(NSDictionary *)data {
    self.messageOutput = data[@"msg"];
//    let jsonData = try JSONSerialization.data(withJSONObject: msg.output, options: .prettyPrinted)
//    self.tvOutput.text = String(data:jsonData, encoding:.utf8)
    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject: self.messageOutput.output
                                                      options:NSJSONWritingPrettyPrinted
                                                        error:&error];
    self.tvOutputMessage.text = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSLog(@"output text: %@", [messageOutput getText]);
    self.lblOutputText.text = [messageOutput getText];
}
- (void)messageKit:(COGIMessageKit *)messageKit event:(NSString *)event data:(NSDictionary *)data {
    NSLog(@"event: %@", event);
    if ([event isEqualToString:@"CHAT_TTS_DATA"]) {
        NSString *ttsDataStr = data[@"data"];
        NSData *ttsData = [[NSData alloc] initWithBase64EncodedString:ttsDataStr options:0];
        AVAudioSession *session = AVAudioSession.sharedInstance;
        NSError *error = nil;
       [session setCategory:AVAudioSessionCategoryPlayAndRecord
                           mode:AVAudioSessionModeDefault
                        options:AVAudioSessionCategoryOptionDefaultToSpeaker
                          error:&error];
        self.audioPlayer = [[AVAudioPlayer alloc] initWithData:ttsData error:&error];
        [self.audioPlayer prepareToPlay];
        [self.audioPlayer stop];
        [self.audioPlayer setCurrentTime:0];
        [self.audioPlayer play];
    }
}

@end

