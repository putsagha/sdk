//
//  MessageKitViewController.swift
//  SwiftDev
//
//  Created by toka on 2022/07/05.
//  Copyright © 2022 mww. All rights reserved.
//

import UIKit
import AVFAudio

import COGIChatBotKit

class MessageKitViewController: ViewController, COGIMessageKitDelegate, AudioControllerDelegate {
    var hostUrl = "https://c47b-221-146-202-232.ngrok.io" //"https://v2.aiware.io/service"
    var projectId = "a885f8ac-310a-41e6-b394-b68fdc28cf2a" //"e3789209-7ea0-481e-98d2-25562889e2dd"
    var apiKey = "apikey"
    
    var cogiMessageKit: COGIMessageKit?
    
    var channels: UInt32 = 1
    var sampleRate: Double = 8000.0
    var ptime: Double = 100.0
    
    var messageId: String?
    
    var audioPlayer: AVAudioPlayer?
    
    var sttResult: COGISttResult?
    var messageOutput: COGIMessageOutput?
    
    var tasks: [[AnyHashable: Any]] = []
    var selectedTaskId = ""
    
    @IBOutlet weak var taskTableView: UITableView!
    
    @IBOutlet weak var lblRecording: UILabel!
    
    @IBOutlet weak var tfSend: UITextField!
    @IBOutlet weak var lblInputText: UILabel!
    @IBOutlet weak var lblOutputText: UILabel!
    @IBOutlet weak var tvOutput: UITextView!
    
    @IBOutlet weak var btnSend: UIButton!
    @IBOutlet weak var btnRecordStart: UIButton!
    @IBOutlet weak var btnRecordStop: UIButton!
    
    @IBOutlet weak var btnTtsSend: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.enableControls(false)
        
        self.lblInputText.text = ""
        self.lblOutputText.text = ""
        self.lblRecording.text = ""
        
        self.startMessageKit()
        
        let gesture = UITapGestureRecognizer(target: self, action: #selector(self.onTapBG(_:)))
        gesture.cancelsTouchesInView = false
        self.view.addGestureRecognizer(gesture)
        
        taskTableView.dataSource = self
        taskTableView.delegate = self
        taskTableView.allowsSelection = true
    }
    
    @objc func onTapBG(_ sender:UITapGestureRecognizer){
        self.view.endEditing(true)
    }
    
    func enableControls(_ enable: Bool) -> Void {
        btnSend.isEnabled = enable
        btnRecordStart.isEnabled = enable
        btnRecordStop.isEnabled = enable
        btnTtsSend.isEnabled = enable
    }

    func startMessageKit() -> Void {
        let config = COGIMessageKitConfig()
        
        config.hostUrl = self.hostUrl
        config.projectId = self.projectId
        config.delegate = self
        if apiKey.count > 0 {
            config.apiKey = apiKey
            config.userKey = "111"
            config.secure = [
                "name" : "누구누구"
            ]
        }
        config.ownerView = self.view
        config.allowSelfSignedCert = true
        config.encrypt = true
//        config.additionalUserAgent = "test"
//        config.extra = "version=dev"
//        COGILogger.sharedInstance().logLevel = Int32(kCGLLDebug)

        self.cogiMessageKit = COGIMessageKit(config: config)
    }
    
    func audioCheck(callback:@escaping (()->Void), deniedCallback:@escaping (()->Void)) {
        switch AVAudioSession.sharedInstance().recordPermission {
        case .granted:
            callback()
            break
        case .denied:
            deniedCallback()
            break
        case .undetermined:
            AVAudioSession.sharedInstance().requestRecordPermission { granted in
                if granted {
                    DispatchQueue.main.async {
                        callback()
                    }
                } else {
                    DispatchQueue.main.async {
                        deniedCallback()
                    }
                }
            }
            break
        @unknown default:
            deniedCallback()
        }
    }

    @IBAction func onBack(_ sender: Any) {
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }

    @IBAction func onSend(_ sender: Any) {
        guard let text = self.tfSend.text, !text.isEmpty else {
            return
        }
        self.cogiMessageKit?.inputMessage(text)
        self.view.endEditing(true)
    }
    
    
    @IBAction func onReset(_ sender: Any) {
        tasks.removeAll()
        taskTableView.reloadData()
        self.cogiMessageKit?.inputExtra(["reset": "true"])
    }
    
    @IBAction func onRecordStart(_ sender: Any) {
        self.enableControls(false)
        btnRecordStop.isEnabled = true
        self.cogiMessageKit?.startStt()
    }
    
    @IBAction func onRecordEnd(_ sender: Any) {
        self.cogiMessageKit?.stopStt()
    }
    
    @IBAction func onSendSttResult(_ sender: Any) {
        if let sttResult = sttResult {
            // stt결과물로 온 text를 챗봇에 입력
            self.cogiMessageKit?.inputSttMessage(sttResult)
        }
    }
    
    @IBAction func onTTSSend(_ sender: Any) {
        if let messageOutput = messageOutput {
            // messageKitMessageReceived 로 받은 messageOutput을 tts에 음성데이터로 전환 요청
            self.cogiMessageKit?.requestTtsData(messageOutput)
        }
    }

    @IBAction func onSendTask(_ sender: Any) {
        if selectedTaskId.count > 0 {
            cogiMessageKit?.inputExtra(["taskId": selectedTaskId])
        }
    }

    // MARK: - COGIMessageKitDelegate
    func messageKitDidStartLoad(_ messageKit: COGIMessageKit) {
        print("start")
    }

    // on loading complete
    func messageKitDidFinishLoad(_ messageKit: COGIMessageKit) {
        self.enableControls(true)
    }
    
    // on loading failed
    func messageKitDidFailLoad(_ messageKit: COGIMessageKit) {
        print("failed load")
    }
    
    // on send message
    func messageKitMessageSent(_ messageKit: COGIMessageKit) {
        print("sent")
    }
    
    // deprecated
    func messageKit(_ messageKit: COGIMessageKit, didReceiveError message: String) {
        print("error : \(message)")
    }
    
    // error messages from chatbot
    func messageKit(_ messageKit: COGIMessageKit, didReceiveError errorCode: COGIErrorCode, message: String?, data: [AnyHashable : Any]?) {
        print("error : \(errorCode) \(message)")
    }
    
    // on received respone output
    func messageKitMessageReceived(_ messageKit: COGIMessageKit, data: [AnyHashable : Any]) {
        self.enableControls(true)

        self.lblOutputText.text = ""
        
        if let msg = data["msg"] as? COGIMessageOutput {
            print("received text : \(msg.getText())")
            do {
                let jsonData = try JSONSerialization.data(withJSONObject: msg.output, options: .prettyPrinted)
                self.tvOutput.text = String(data:jsonData, encoding:.utf8)
                self.lblOutputText.text = msg.getText()
                self.messageOutput = msg

            } catch {
                print(error.localizedDescription)
            }
            
            tasks.removeAll()
            selectedTaskId = ""
            
            for output in msg.output {
                if let output = output as? [AnyHashable: Any] {
                    if let type = output["type"] as? String {
                        if type == "tasklist" {
                            if let items = output["items"] as? NSArray {
                                if items.count > 0 {
                                    for item in items {
                                        if let item = item as? [AnyHashable: Any] {
                                            tasks.append(item)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if tasks.count > 0 {
                taskTableView.reloadData()
            }
            
        }
    }
    
    // 메세지 전송 실패시
    func messageKitMessageSendFailed(_ messageKit: COGIMessageKit, data: [AnyHashable : Any]) {
        if let reason = data["reason"] {
            print("send failed \(reason)")

        }
    }

    // on events - post front, stt, etc...
    func messageKit(_ messageKit: COGIMessageKit, event: String, data: [AnyHashable : Any]?) {
        switch event {
        // 챗봇 관련 세팅 이벤트
        case "CHAT_SETTING_UPDATED":
            // stt, tts 관련 세팅(sample rate, channel 수 등) 받아서 세팅
            if let data = data, let speech = data["speech"] as? NSDictionary, let stt = speech["stt"] as? NSDictionary, let audioFormat = stt["audioFormat"] as? NSDictionary {
                print("data: \(data)")
                print("audio format: \(audioFormat)")
                if let sampleRate = audioFormat["sampleRate"] as? NSNumber {
                    self.sampleRate = sampleRate.doubleValue
                }
                if let channels = audioFormat["channels"] as? NSNumber {
                    self.channels = channels.uint32Value
                }
                if let ptime = audioFormat["ptime"] as? NSNumber {
                    self.ptime = ptime.doubleValue
                }
                let ac = AudioController_for_test_only.sharedInstance
                ac.delegate = self
                let _ = ac.prepare(sampleRate: self.sampleRate, channels: self.channels)

            }
        
        // STT로 음성 데이터 전송 준비 완료 이벤트
        case "CHAT_STT_SOCKET_OPEN":
            self.lblRecording.text = "recording"
            self.sttResult = nil
            self.audioCheck {
                let ac = AudioController_for_test_only.sharedInstance
                let _ = ac.start()
            } deniedCallback: {
                print("need audio premission")
            }


        // 전송 받은 음성데이터를 전환한 text data
        // 무음 발생하여 음성 입력 완료시 isFinal true로 전달
        case "CHAT_STT_SOCKET_DATA":
            if let data = data {
                print("data: \(data)")
                if let result = data["result"] as? COGISttResult {
                    print("text: \(result.text), id: \(result.sttId)")
                    if result.isFinal {
                        // 최종 stt인식된 text
                        let ac = AudioController_for_test_only.sharedInstance
                        let _ = ac.stop()
                        self.sttResult = result
                        
                        self.lblInputText.text = result.text
                        self.lblRecording.text = ""
                        self.enableControls(true)
                    }
                }
            }
        
        // 최종 stt인식되어 text 전달후 stt와 연결 종료 이벤트
        case "CHAT_STT_SOCKET_CLOSE":
            print("stt end")
            self.lblRecording.text = ""
            self.enableControls(true)
            
        case "CHAT_STT_SOCKET_ERROR":
            print("stt error")
            let ac = AudioController_for_test_only.sharedInstance
            let _ = ac.stop()
            self.lblRecording.text = ""
            self.enableControls(true)

        // tts요청시 변환된 음성 데이터 전달
        case "CHAT_TTS_DATA":
            if let data = data, let ttsData = data["data"] as? NSData {
                try? AVAudioSession.sharedInstance().setCategory(.playAndRecord, mode: .default, policy: .default, options: .defaultToSpeaker)
                self.audioPlayer = try? AVAudioPlayer(data: ttsData as Data)
                self.audioPlayer?.prepareToPlay()
                self.audioPlayer?.stop()
                self.audioPlayer?.currentTime = 0
                self.audioPlayer?.play()
            }
        
        // postFront action 이벤트
        case "CHAT_ACTION":
            if let data = data {
                print("postFront action >>> \(data)")
            }

        default:
            print("other event >>> \(event)")
        }
    }

    // MARK: - AudioControllerDelegate
    func processSampleData(data: Data) {
        self.cogiMessageKit?.sendSttData(data)
    }
}


extension MessageKitViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell", for: indexPath) as! TaskTableViewCell
        if let taskName = tasks[indexPath.row]["taskName"] as? String {
            cell.taskName.text = taskName
        }
        return cell
    }
    
    
}

extension MessageKitViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let taskId = tasks[indexPath.row]["taskId"] as? String {
            selectedTaskId = taskId
        }

    }
}
