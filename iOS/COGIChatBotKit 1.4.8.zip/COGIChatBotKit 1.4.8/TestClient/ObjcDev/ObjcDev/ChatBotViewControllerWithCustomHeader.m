//
//  ChatBotViewControllerWithCustomHeader.m
//  ObjcDev
//
//  Created by tokasia on 2020/06/26.
//  Copyright © 2020 mww. All rights reserved.
//

#import "ChatBotViewControllerWithCustomHeader.h"
#import <COGIChatBotKit/COGIChatBotKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ChatBotViewControllerWithCustomHeader () <CLLocationManagerDelegate>
@property (weak, nonatomic) IBOutlet COGIChatBotView *chatBotView;
@property (nonatomic, retain) CLLocationManager *locationManager;
@end

@implementation ChatBotViewControllerWithCustomHeader
@synthesize config;
- (void)viewDidLoad {
    [super viewDidLoad];
    
	[self.chatBotView initialize:self.config];
}

- (IBAction)onBack:(id)sender {
	[self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - ChatBotViewDelegate
// 로딩 시작 이벤트
- (void)chatBotViewDidStartLoad:(COGIChatBotView *)chatBotView{
	NSLog(@"chatBotViewDidStartLoad");
}

// 로딩 완료 이벤트
- (void)chatBotViewDidFinishLoad:(COGIChatBotView *)chatBotView{
	NSLog(@"chatBotViewDidFinishLoad");
	// chatbot 이 로드되면 location service를 시작한다.
	[self.locationManager startUpdatingLocation];
}

// 로딩실패 -  닫기 처리등을 하여 이전  화면으로 돌아간다.
- (void)chatBotViewDidFailLoad:(COGIChatBotView *)chatBotView{
	NSLog(@"chatBotViewDidFailLoad");
	[self dismissViewControllerAnimated:TRUE completion:nil];
}

// deprecated
- (void)chatBotView:(COGIChatBotView *)chatBotView didReceiveError:(NSString *)message{
    NSLog(@"error : %@", message);
}

//오류 메시지
- (void)chatBotView:(COGIChatBotView *)chatBotView didReceiveError:(COGIErrorCode)errorCode message:(NSString *)message data:(NSDictionary *)data {
    NSLog(@"error : %lu, %@", (unsigned long)errorCode, message);
}


//action 이벤트 처리 / Postfront button, cg-action postfront 처리
- (void)chatBotView:(COGIChatBotView *)chatBotView action:(NSString *)data{
	NSLog(@"action >>> %@", data);
	if ([data isKindOfClass:[NSDictionary class]]) {
		NSString * name = [((NSDictionary *)data) valueForKey:@"name"];
		NSLog(@"name : %@", name);
	} else if ([data isKindOfClass:[NSString class]]) {
		id json = [NSJSONSerialization JSONObjectWithData:[(NSString*)data dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
		NSLog(@"%@", json);
	}
}

// 유저 메세지가 전송됬을때 호출
- (void)chatBotViewChatMessageSent:(COGIChatBotView *)chatBotView {
	NSLog(@"chatBotViewChatMessageSent");
}



#pragma mark CLLocationManagerDelegate
// location정보를  챗봇에 업데이트 한다
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
	CLLocation *location = [locations lastObject];
	NSDictionary *loc = @{
						  @"latitude" : @"111",//[NSNumber numberWithDouble:location.coordinate.latitude ],
						  @"longitude" : @"222"//[NSNumber numberWithDouble:location.coordinate.longitude ]
						  };
	if (self.chatBotView) {
		[self.chatBotView sendMessage:@"LOCATION_UPDATE" data:loc];
	}
}

@end
