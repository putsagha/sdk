//
//  ChatBotViewControllerWithHeader.h
//  ObjcDev
//
//  Created by tokasia on 2020/06/26.
//  Copyright © 2020 mww. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <COGIChatBotKit/COGIChatBotKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ChatBotViewControllerWithHeader : UIViewController <COGIChatBotViewDelegate>
@property (nonatomic) COGIChatBotConfig *config;
@end

NS_ASSUME_NONNULL_END
