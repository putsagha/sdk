//
//  main.m
//  ObjcDev
//
//  Created by tokasia on 02/05/2019.
//  Copyright © 2019 mww. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
