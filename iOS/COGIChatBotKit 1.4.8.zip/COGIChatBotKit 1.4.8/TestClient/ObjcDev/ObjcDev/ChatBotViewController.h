//
//  ChatBotViewController.h
//  ObjcDev
//
//  Created by tokasia on 2020/03/02.
//  Copyright © 2020 mww. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <COGIChatBotKit/COGIChatBotKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ChatBotViewController : UIViewController <COGIChatBotViewDelegate>
@property (nonatomic) COGIChatBotConfig *config;
@end

NS_ASSUME_NONNULL_END
