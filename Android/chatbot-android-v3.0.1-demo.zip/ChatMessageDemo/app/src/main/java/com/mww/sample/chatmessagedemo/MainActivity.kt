package com.mww.sample.chatmessagedemo

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.mww.chatbot.ChatData
import com.mww.chatbot.ChatLog
import com.mww.chatbot.error.ChatError
import com.mww.chatbot.service.ChatDialogMessage
import com.mww.chatbot.service.ChatService
import com.mww.chatbot.service.ChatSpeechText
import com.mww.chatbot.service.dialog.ChatDialogEventListener
import com.mww.chatbot.service.speech.ChatSpeechEventListener
import com.mww.chatbot.view.ChatSetting
import com.mww.chatbot.view.ChatView
import com.mww.chatbot.view.ChatViewEvent
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream

private const val REQUEST_PERMISSION = 1001
private const val SERVER_URL = "https://v2.aiware.io/service"
private const val PROJECT_ID = "e3789209-7ea0-481e-98d2-25562889e2dd"

class MainActivity : AppCompatActivity() {
    private lateinit var chatService: ChatService
    private lateinit var startSTTButton: Button
    private lateinit var stopSTTButton: Button
    private lateinit var sttResultText: TextView
    private lateinit var inputSTTButton: Button
    private lateinit var dialogResultText: TextView
    private lateinit var playTTSButton: Button

    private var recorder: DemoRecorder? = null
    private var speechText: ChatSpeechText? = null
    private var dialogMessage: ChatDialogMessage? = null

    private val chatEventListener = object: ChatViewEvent() {
        override fun onChatCreate() {
            initialize()
        }

        override fun onError(error: ChatError?) {
            error?.let {
                debug("error.URL", error.requestUrl)
                debug("error.Code", "${error.code}")
                debug("error.Description", error.description)
            }
        }
    }

    private fun debug(title: String, content: String) {
        Log.d("ChatMessageDemo", "(${title}): [${content}]")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ChatLog.setDebug(true)

        chatService = ChatService(this).apply {
            val setting = ChatSetting.Builder()
                .setServerUrl(SERVER_URL)
                .setProjectId("${PROJECT_ID}/voice-dialog")
                .setVersion("dev")
                .build()

            start(setting, chatEventListener)
        }

        startSTTButton = findViewById<Button>(R.id.start_stt_button).apply {
            setOnClickListener {
                chatService.speech.startListen()
            }
        }

        stopSTTButton = findViewById<Button>(R.id.stop_stt_button).apply {
            setOnClickListener {
                chatService.speech.stopListen()
            }
        }

        inputSTTButton = findViewById<Button>(R.id.input_stt_button).apply {
            setOnClickListener {
                speechText?.let {
                    chatService.dialog.inputMessage(it)
                }
            }
        }

        playTTSButton = findViewById<Button>(R.id.play_tts_button).apply {
            setOnClickListener {
                dialogMessage?.let {
                    chatService.speech.sendText(it)
                }
            }
        }

        sttResultText = findViewById(R.id.stt_result_text)
        dialogResultText = findViewById(R.id.dialog_result_text)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if( REQUEST_PERMISSION == requestCode && grantResults[0] == PackageManager.PERMISSION_GRANTED ) {
            startRecording()
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    private fun initialize() {
        chatService.speech.setSpeechEventListener(object: ChatSpeechEventListener {
            override fun onTranscript(text: ChatSpeechText?) {
                text?.let {
                    debug("transcript", "text[${it.transcript}] isFinal[${it.isFinal}]")

                    if( it.isFinal ) {
                        updateSpeechText(it)
                    }
                }
            }

            override fun onStart() {
                startRecording()
            }

            override fun onStop() {
                stopRecording()
            }

            override fun onVoice(data: ByteArray?) {
                playTTSButton.isEnabled = false

                playVoiceAudio(writeToFile(data)) {
                    startSTTButton.isEnabled = true
                }
            }
        })

        chatService.dialog.setDialogEventListener(object: ChatDialogEventListener {
            override fun onReceive(message: ChatDialogMessage?) {
                message?.let {
                    updateDialogMessage(it)
                }
            }
        })

        startSTTButton.isEnabled = true
    }

    private fun startRecording() {
        if(recorder?.isRunning() == true) {
            return
        }

        if( checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_PERMISSION)
        } else {
            val audioRecord = AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(chatService.speech.config.sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build())
                .build()

            val onData = { data: ByteArray ->
                chatService.speech.sendBytes(data)
            }

            val onError = { code: Int ->
                Toast.makeText(this, "Recording Error: $code", Toast.LENGTH_SHORT).show()
            }

            recorder = DemoRecorder(audioRecord, onData, onError).apply {
                start()
            }
        }
    }

    private fun stopRecording() {
        recorder?.stop()

        startSTTButton.isEnabled = true
    }

    private fun updateDialogMessage(message: ChatDialogMessage) {
        dialogMessage = message
        dialogResultText.text = message.output.toString(8)

        inputSTTButton.isEnabled = false
        playTTSButton.isEnabled = true
    }

    private fun updateSpeechText(text: ChatSpeechText) {
        speechText = text
        sttResultText.text = text.transcript

        startSTTButton.isEnabled = false
        inputSTTButton.isEnabled = true
    }

    private fun writeToFile(data: ByteArray?): File {
        val file = File(externalCacheDir, "voice_temp.wav")

        FileOutputStream(file).use {
            it.write(data)
        }

        return file
    }

    private fun playVoiceAudio(file: File, complete: () -> Unit) {
        val mp = MediaPlayer.create(this, Uri.fromFile(file))

        mp?.let {
            mp.start()
            mp.setOnCompletionListener {
                complete()
            }
        }
    }
}