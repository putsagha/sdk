package com.mww.sample.chatmessagedemo

import android.media.AudioRecord
import android.os.Handler
import android.os.Looper

class DemoRecorder(
    private val audioRecord: AudioRecord,
    private val onData: (data: ByteArray) -> Unit,
    private val onError: (code: Int) -> Unit
) {
    private var running = false
    private val mainHandler = Handler(Looper.getMainLooper())

    fun start() {
        if( running ) return

        val thread = Thread {
            val bufferSize = AudioRecord.getMinBufferSize(
                audioRecord.sampleRate,
                audioRecord.channelCount,
                audioRecord.audioFormat
            )

            val buffer = ByteArray(bufferSize)

            running = true

            audioRecord.startRecording()

            while( running ) {
                val size = audioRecord.read(buffer, 0, bufferSize)

                if( size >= 0 ) {
                    val data = buffer.copyOfRange(0, size)

                    mainHandler.post {
                        onData(data)
                    }
                } else {
                    mainHandler.post {
                        onError(size)
                    }

                    running = false
                }
            }

            audioRecord.stop()
            audioRecord.release()
        }

        thread.start()
    }

    fun stop() {
        running = false
    }

    fun isRunning(): Boolean {
        return running
    }
}